class Country {
    constructor() { 
        this.id = null;
        this.countryCode = null;
        this.currency = null;
        this.exchangeRate = null;
        this.name = null;
    }
}
module.exports = Country;