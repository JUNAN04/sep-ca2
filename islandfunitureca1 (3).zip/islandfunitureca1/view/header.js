document.write('\
<head>\
    <meta charset="utf-8">\
    <title>Island Furniture</title>\
    <link rel="stylesheet" href="/vendor/bootstrap/css/bootstrap.css">\
    <link rel="stylesheet" href="/vendor/font-awesome/css/font-awesome.css">\
    <link rel="stylesheet" href="/vendor/owl-carousel/owl.carousel.css" media="screen">\
    <link rel="stylesheet" href="/vendor/owl-carousel/owl.theme.css" media="screen">\
    <link rel="stylesheet" href="/vendor/magnific-popup/magnific-popup.css" media="screen">\
    <link rel="stylesheet" href="/vendor/isotope/jquery.isotope.css" media="screen">\
    <link rel="stylesheet" href="/vendor/mediaelement/mediaelementplayer.css" media="screen">\
    \
    <link rel="stylesheet" href="/css/theme.css">\
    <link rel="stylesheet" href="/css/theme-elements.css">\
    <link rel="stylesheet" href="/css/theme-blog.css">\
    <link rel="stylesheet" href="/css/theme-shop.css">\
    <link rel="stylesheet" href="/css/theme-animate.css">\
    \
    <link rel="stylesheet" href="/vendor/rs-plugin/css/settings.css" media="screen">\
    <link rel="stylesheet" href="/vendor/circle-flip-slideshow/css/component.css" media="screen">\
    \
    <link rel="stylesheet" href="/css/theme-responsive.css" />\
    <link rel="stylesheet" href="/B/css/default.css">\
    \
    <script src="/vendor/modernizr.js"></script>\
    <script src="/vendor/jquery.js"></script>\
    <script src="/vendor/jquery.appear.js"></script>\
    <script src="/vendor/jquery.easing.js"></script>\
    <script src="/vendor/jquery.cookie.js"></script>\
    <script src="/vendor/bootstrap/js/bootstrap.js"></script>\
    <script src="/vendor/jquery.validate.js"></script>\
    <script src="/vendor/jquery.stellar.js"></script>\
    <script src="/vendor/jquery.knob.js"></script>\
    <script src="/vendor/jquery.gmap.js"></script>\
    <script src="/vendor/twitterjs/twitter.js"></script>\
    <script src="/vendor/isotope/jquery.isotope.js"></script>\
    <script src="/vendor/owl-carousel/owl.carousel.js"></script>\
    <script src="/vendor/jflickrfeed/jflickrfeed.js"></script>\
    <script src="/vendor/magnific-popup/magnific-popup.js"></script>\
    <script src="/vendor/mediaelement/mediaelement-and-player.js"></script>\
    \
    <link rel="stylesheet" href="/@fortawesome/fontawesome-free/css/all.css">\
</head>');