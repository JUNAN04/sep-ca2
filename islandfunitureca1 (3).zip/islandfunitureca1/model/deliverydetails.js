class DeliveryDetails {
    constructor() { 
        this.id = null;
        this.memberId = null;
        this.salesRecordId = null;
        this.address = null;
        this.postalCode = null;
        this.contactNum = null;
        this.name = null;
    }
}
module.exports = DeliveryDetails;