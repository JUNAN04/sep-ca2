class StorageBin {
    constructor() { 
        this.id = null;
        this.length = null;
        this.freeVolume = null;
        this.height = null;
        this.name = null;
        this.type = null;
        this.volume = null;
        this.width = null;
        this.warehouseId = null;
    }
}
module.exports = StorageBin;