class LineItem {
    constructor() { 
        this.id = null;
        this.packtype = null;
        this.quantity = null;
        this.itemId = null;
    }
}
module.exports = LineItem;