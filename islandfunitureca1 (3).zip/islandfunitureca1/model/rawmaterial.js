class RawMaterial {
    constructor() { 
        this.id = null;
        this.dtype = null;
        this.sku = null;
        this.length = null;
        this.category = null;
        this.description = null;
        this.height = null;
        this.name = null;
        this.type = null;
        this.volume = null;
        this.width = null;
        this.warehouseId = null;
    }
}
module.exports = RawMaterial;