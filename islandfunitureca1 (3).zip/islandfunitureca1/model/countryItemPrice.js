class CountryItemPrice {
    constructor() { 
        this.itemId = null;
        this.sku = null;
        this.countryId = null;
        this.countryName = null;
        this.retailPrice = null;
    }
}
module.exports = CountryItemPrice;